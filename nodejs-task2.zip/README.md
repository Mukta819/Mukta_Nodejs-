# Task 2 - CPU Monitor & Scheduler

## What this project does
- Monitors CPU usage periodically. If CPU usage >= 70% it exits the process (use PM2/systemd to auto-restart).
- POST /schedule to store a message with day/time. Messages are persisted to MongoDB; a scheduler (node-schedule) runs them at the correct time.

## Run
1. npm install
2. npm start
