const express = require('express');
const mongoose = require('mongoose');
const os = require('os');
const { exec } = require('child_process');
const schedule = require('node-schedule');

const ScheduledMessage = require('./models/ScheduledMessage');

const app = express();
app.use(express.json());

const MONGO = process.env.MONGO || 'mongodb://127.0.0.1:27017/task2db';
mongoose.connect(MONGO).then(()=>console.log('Mongo connected')).catch(err=>{console.error(err);process.exit(1);});

// Schedule endpoint
app.post('/schedule', async (req, res) => {
  const { message, day, time } = req.body;
  if(!message || !day || !time) return res.status(400).json({ error: 'message, day, time required' });
  const when = new Date(`${day}T${time}`);
  const doc = await ScheduledMessage.create({ message, when, delivered:false });
  scheduleJob(doc);
  res.json({ ok:true, id: doc._id, when: doc.when });
});

function scheduleJob(doc){
  const now = new Date();
  if(doc.when <= now){
    ScheduledMessage.findByIdAndUpdate(doc._id, { delivered:true, deliveredAt:new Date() }).then(()=>console.log('Delivered late', doc._id));
    return;
  }
  schedule.scheduleJob(doc.when, async () => {
    console.log('Running scheduled job', doc._id, doc.message);
    await ScheduledMessage.findByIdAndUpdate(doc._id, { delivered:true, deliveredAt:new Date() });
  });
}

// on startup schedule pending
(async () => {
  const pending = await ScheduledMessage.find({ delivered:false });
  for(const p of pending) scheduleJob(p);
})();

// CPU monitor: measure CPU usage over 1s window
function cpuAverage(){
  const cpus = os.cpus();
  let user=0,nice=0,sys=0,idle=0,irq=0;
  for(const cpu of cpus){
    user += cpu.times.user;
    nice += cpu.times.nice;
    sys += cpu.times.sys;
    idle += cpu.times.idle;
    irq += cpu.times.irq;
  }
  return { user, nice, sys, idle, irq, total: user+nice+sys+idle+irq };
}

async function getCpuUsagePercent(delayMs=1000){
  const start = cpuAverage();
  await new Promise(r=>setTimeout(r, delayMs));
  const end = cpuAverage();
  const idleDelta = end.idle - start.idle;
  const totalDelta = end.total - start.total;
  const usage = 1 - (idleDelta / totalDelta);
  return usage * 100;
}

async function startCpuMonitor(threshold=70, intervalMs=10000){
  console.log('Starting CPU monitor threshold', threshold);
  setInterval(async () => {
    try {
      const usage = await getCpuUsagePercent(1000);
      console.log('CPU usage:', usage.toFixed(1)+'%');
      if(usage >= threshold){
        console.warn('CPU >= threshold. Exiting process for restart.');
        process.exit(1); // run under pm2/systemd to restart
      }
    } catch(err){ console.error('CPU monitor error', err); }
  }, intervalMs);
}

startCpuMonitor(70, 10000);

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Task2 server listening on', PORT));
