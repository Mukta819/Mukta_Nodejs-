const mongoose = require('mongoose');
const schema = new mongoose.Schema({ message:String, when:Date, delivered:{type:Boolean,default:false}, deliveredAt:Date }, { timestamps:true });
module.exports = mongoose.model('ScheduledMessage', schema);
