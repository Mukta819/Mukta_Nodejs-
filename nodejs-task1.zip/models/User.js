const mongoose = require('mongoose');
const schema = new mongoose.Schema({ firstName:String, dob:Date, address:String, phone:String, state:String, zip:String, email:{type:String,index:true}, gender:String, userType:String }, { timestamps:true });
module.exports = mongoose.model('User', schema);
