const mongoose = require('mongoose');
const schema = new mongoose.Schema({ company_name:String }, { timestamps:true });
module.exports = mongoose.model('Carrier', schema);
