const mongoose = require('mongoose');
const schema = new mongoose.Schema({ policyNumber:String, startDate:Date, endDate:Date, account:{type:mongoose.Schema.Types.ObjectId,ref:'Account'}, agent:{type:mongoose.Schema.Types.ObjectId,ref:'Agent'}, lob:{type:mongoose.Schema.Types.ObjectId,ref:'LOB'}, carrier:{type:mongoose.Schema.Types.ObjectId,ref:'Carrier'}, user:{type:mongoose.Schema.Types.ObjectId,ref:'User'}, raw:{} }, { timestamps:true });
module.exports = mongoose.model('Policy', schema);
