const mongoose = require('mongoose');
const schema = new mongoose.Schema({ accountName:String }, { timestamps:true });
module.exports = mongoose.model('Account', schema);
