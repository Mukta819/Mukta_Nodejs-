const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const { Worker } = require('worker_threads');

const Agent = require('./models/Agent');
const User = require('./models/User');
const Account = require('./models/Account');
const Lob = require('./models/LOB');
const Carrier = require('./models/Carrier');
const Policy = require('./models/Policy');

const app = express();
app.use(express.json());

const MONGO = process.env.MONGO || 'mongodb://127.0.0.1:27017/task1db';
mongoose.connect(MONGO).then(()=>console.log('Mongo connected')).catch(err=>{console.error(err);process.exit(1);});

const upload = multer({ dest: path.join(__dirname,'uploads/') });

// Upload endpoint - parsing done inside worker thread
app.post('/upload', upload.single('file'), (req, res) => {
  if(!req.file) return res.status(400).json({ error: 'file required' });
  const worker = new Worker(path.join(__dirname,'worker.js'), {
    workerData: { filepath: req.file.path, originalname: req.file.originalname }
  });

  worker.on('message', async (msg) => {
    if(msg.error) return res.status(500).json({ error: msg.error });
    const rows = msg.rows;
    try {
      for(const r of rows){
        // adjust these keys if your CSV headers differ
        const agentName = r['Agent - Agent Name'] || r.agentName || r.Agent;
        const firstName = r['first name'] || r.firstName || r.FirstName || r.firstName;
        const email = r.email || r.Email;
        const accountName = r['Account Name'] || r.accountName;
        const category = r['category_name'] || r.category_name || r['Policy Category'];
        const company = r['company_name'] || r.company_name || r['Policy Carrier'];
        const policyNumber = r['policy number'] || r.policyNumber || r['Policy Number'];

        const agentDoc = await Agent.findOneAndUpdate({ name: agentName }, { name: agentName }, { upsert:true, new:true });
        const userDoc = await User.findOneAndUpdate({ email }, {
          firstName,
          dob: r.DOB ? new Date(r.DOB) : (r.dob ? new Date(r.dob) : null),
          address: r.address,
          phone: r['phone number'] || r.phone,
          state: r.state,
          zip: r['zip code'] || r.zip,
          email,
          gender: r.gender,
          userType: r.userType
        }, { upsert:true, new:true });

        const accountDoc = await Account.findOneAndUpdate({ accountName }, { accountName }, { upsert:true, new:true });
        const lobDoc = await Lob.findOneAndUpdate({ category_name: category }, { category_name: category }, { upsert:true, new:true });
        const carrierDoc = await Carrier.findOneAndUpdate({ company_name: company }, { company_name: company }, { upsert:true, new:true });

        await Policy.findOneAndUpdate({ policyNumber }, {
          policyNumber,
          startDate: r['policy start date'] ? new Date(r['policy start date']) : (r.policyStartDate ? new Date(r.policyStartDate) : null),
          endDate: r['policy end date'] ? new Date(r['policy end date']) : (r.policyEndDate ? new Date(r.policyEndDate) : null),
          account: accountDoc._id,
          agent: agentDoc._id,
          lob: lobDoc._id,
          carrier: carrierDoc._id,
          user: userDoc._id,
          raw: r
        }, { upsert:true, new:true });
      }
      res.json({ ok: true, imported: rows.length });
    } catch(err){
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  worker.on('error', (err) => {
    console.error('Worker error', err);
    res.status(500).json({ error: err.message });
  });
});

// Search by username or email
app.get('/search', async (req, res) => {
  const q = req.query.q;
  if(!q) return res.status(400).json({ error: 'q query param required' });
  const users = await User.find({ $or: [{ firstName: new RegExp(q,'i') }, { email: new RegExp(q,'i') }] });
  const ids = users.map(u=>u._id);
  const policies = await Policy.find({ user: { $in: ids } }).populate('user agent account lob carrier').lean();
  res.json({ count: policies.length, policies });
});

// Aggregation
app.get('/aggregate/policies-by-user', async (req, res) => {
  const agg = await Policy.aggregate([
    { $group: { _id: '$user', policiesCount: { $sum: 1 }, policies: { $push: '$$ROOT' } } },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
    { $unwind: '$user' },
    { $project: { _id:0, userId: '$user._id', userName: '$user.firstName', email: '$user.email', policiesCount:1, policies:1 } }
  ]);
  res.json(agg);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, ()=>console.log('Task1 server listening on', PORT));
