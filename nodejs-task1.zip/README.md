# Task 1 - Upload & Policy APIs (Worker Threads)

## What this project does
- POST /upload : upload CSV/XLSX file (field name `file`). Parsing happens in a worker thread and rows are upserted into MongoDB collections:
  - Agent, User, Account, LOB, Carrier, Policy
- GET /search?q=<name|email> : find policies for a username or email
- GET /aggregate/policies-by-user : aggregated policies per user

## Run
1. Install dependencies: `npm install`
2. Start MongoDB locally (or set MONGO env var)
3. `npm start`
4. Upload file using Postman: POST http://localhost:3000/upload (form-data `file`)

Note: adjust CSV/XLSX headers mapping in server.js if your file uses different column names.
