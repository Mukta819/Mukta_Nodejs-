const { parentPort, workerData } = require('worker_threads');
const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');
const { parse } = require('csv-parse/sync');

function parseFile(filepath, originalname){
  const ext = path.extname(originalname).toLowerCase();
  const buf = fs.readFileSync(filepath);
  if(ext === '.xlsx' || ext === '.xls'){
    const wb = xlsx.read(buf, { type: 'buffer' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    return xlsx.utils.sheet_to_json(ws, { defval: null });
  } else {
    const text = buf.toString('utf8');
    return parse(text, { columns: true, skip_empty_lines: true });
  }
}

try{
  const rows = parseFile(workerData.filepath, workerData.originalname);
  parentPort.postMessage({ rows });
} catch(err){
  parentPort.postMessage({ error: err.message });
}
